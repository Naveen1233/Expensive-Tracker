import React from 'react'

export const Header = () => {
  return <h2>Monthly Expense Tracker</h2>
}
